<div class="lista-logos">
    <img class="logo-bordado" src="/wp-content/themes/oceanwp/assets/img/logos/1.jpg" data-value="Sem logo_0" alt="Sem logo" title="Sem logo bordado">
    <img class="logo-bordado" src="/wp-content/themes/oceanwp/assets/img/logos/4.jpg" data-value="Biomedicina_1" alt="Biomedicina" title="Biomedicina">
    <img class="logo-bordado" src="/wp-content/themes/oceanwp/assets/img/logos/2.jpg" data-value="Acupuntura_2" alt="Acupuntura" title="Acupuntura">
    <img class="logo-bordado" src="/wp-content/themes/oceanwp/assets/img/logos/3.jpg" data-value="Acupuntura 2_3" alt="Acupuntura 2" title="Acupuntura 2">
    <img class="logo-bordado" src="/wp-content/themes/oceanwp/assets/img/logos/5.jpg" data-value="Enfermagem_4" alt="Enfermagem" title="Enfermagem">
    <img class="logo-bordado" src="/wp-content/themes/oceanwp/assets/img/logos/6.jpg" data-value="Farmácia_5" alt="Farmácia" title="Farmácia">
    <img class="logo-bordado" src="/wp-content/themes/oceanwp/assets/img/logos/7.jpg" data-value="Fisioterapia_6" alt="Fisioterapia" title="Fisioterapia">
    <img class="logo-bordado" src="/wp-content/themes/oceanwp/assets/img/logos/8.jpg" data-value="Fonoaudiologia_7" alt="Fonoaudiologia" title="Fonoaudiologia">
    <img class="logo-bordado" src="/wp-content/themes/oceanwp/assets/img/logos/9.jpg" data-value="Nutrição_8" alt="Nutrição" title="Nutrição">
    <img class="logo-bordado" src="/wp-content/themes/oceanwp/assets/img/logos/10.jpg" data-value="Odontologia_9" alt="Odontologia" title="Odontologia">
    <img class="logo-bordado" src="/wp-content/themes/oceanwp/assets/img/logos/11.jpg" data-value="Psicologia_10" alt="Psicologia" title="Psicologia">
    <img class="logo-bordado" src="/wp-content/themes/oceanwp/assets/img/logos/13.jpg" data-value="Radiologia_11" alt="Radiologia" title="Radiologia">
    <img class="logo-bordado" src="/wp-content/themes/oceanwp/assets/img/logos/14.jpg" data-value="Assistência Social_12" alt="Assistência Social" title="Assistência Social">
    <img class="logo-bordado" src="/wp-content/themes/oceanwp/assets/img/logos/15.jpg" data-value="Veterinária_13" alt="Medicina Veterinária" title="Medicina Veterinária">
    <img class="logo-bordado" src="/wp-content/themes/oceanwp/assets/img/logos/16.jpg" data-value="Medicina_14" alt="Medicina" title="Medicina">
    <img class="logo-bordado" src="/wp-content/themes/oceanwp/assets/img/logos/17.jpg" data-value="Medicina 2_15" alt="Medicina 2" title="Medicina 2">
    <img class="logo-bordado" src="/wp-content/themes/oceanwp/assets/img/logos/18.jpg" data-value="Técnico em Enfermagem_16" alt="Técnico em enfermagem" title="Técnico em enfermagem">
    <img class="logo-bordado" src="/wp-content/themes/oceanwp/assets/img/logos/19.jpg" data-value="Serviço Social_17" alt="Serviço Social" title="Serviço Social">
    <img class="logo-bordado" src="/wp-content/themes/oceanwp/assets/img/logos/20.jpg" data-value="Grupo Qualidade em Saúde_18" alt="Grupo Qualidade em Saúde" title="Grupo Qualidade em Saúde">
    <img class="logo-bordado" src="/wp-content/themes/oceanwp/assets/img/logos/21.jpg" data-value="Saúde Estética_19" alt="Saúde Estética" title="Saúde Estética">
    <img class="logo-bordado" src="/wp-content/themes/oceanwp/assets/img/logos/22.jpg" data-value="Podóloga_20" alt="Podóloga" title="Podóloga">
</div>